<?php

//if($_SERVER['REQUEST_SCHEME']=='https') header('Location: http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
define('RUTA', 'http://baguerserv.net/web-admin');


$DBVARS = array(
    'usuario' => 'stirpe_iaw',
    'clave' => 'iaw2016*-',
    'host' => 'localhost',
    'dbname' => 'stirpe_maestro'
);

/**
 *
Acceso al panel de control
Dominio: globaltyt.com
Enlace: https://cloud010.solusoftware.com:8443
Usuario: globaltytcom
Contraseña: ^@A6u8tG

Acceso FTP
Host: cloud010.solusoftware.com
Usuario: globaltytcom
Contraseña: ^@A6u8tG

 *
 */



