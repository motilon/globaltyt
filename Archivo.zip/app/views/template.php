<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Meta -->
  <meta name="description" content="Travel Card.">
  <meta name="author" content="flizcano">

  <title>Globals Tours Travel</title>


  <?php
    /*===============================
    =       Estilo Globales    =
    ===============================*/
    include 'modulos/head/estilos.php';
  ?>
</head>

<body>

  <?php

    /*===============================
    =            Lateral            =
    ===============================*/
    include "modulos/header.php";

    /*===============================
    =            Lateral            =
    ===============================*/
    include "modulos/left.php";

  ?>





  <?php
    /*==================================
    =        Vendors JS            =
    ==================================*/
    
    include "modulos/globalJS.php";
    
  ?>

</body>
</html>
