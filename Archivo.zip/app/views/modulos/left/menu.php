<ul class="br-sideleft-menu">
  <li class="br-menu-item">
    <a href="index.html" class="br-menu-link">
      <i class="menu-item-icon icon ion-ios-home-outline tx-24"></i>
      <span class="menu-item-label">Escritorio</span>
    </a><!-- br-menu-link -->
  </li><!-- br-menu-item -->
  <li class="br-menu-item">
    <a href="mailbox.html" class="br-menu-link">
      <i class="menu-item-icon fa fa-automobile tx-24"></i>
      <span class="menu-item-label">Travel Cart</span>
    </a><!-- br-menu-link -->
  </li><!-- br-menu-item -->
</ul><!-- br-sideleft-menu -->