  <!-- vendor css -->
  <link href="views/lib/font-awesome/css/font-awesome.css" rel="stylesheet">
  <link href="views/lib/Ionicons/css/ionicons.css" rel="stylesheet">
  <link href="views/lib/perfect-scrollbar/css/perfect-scrollbar.css" rel="stylesheet">
  <link href="views/lib/jquery-switchbutton/jquery.switchButton.css" rel="stylesheet">

  <!-- Bracket CSS -->
  <link rel="stylesheet" href="views/css/bracket.css">