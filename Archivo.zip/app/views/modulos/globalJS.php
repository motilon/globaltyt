  <script src="views/lib/jquery/jquery.js"></script>
  <script src="views/lib/popper.js/popper.js"></script>
  <script src="views/lib/bootstrap/bootstrap.js"></script>
  <script src="views/lib/perfect-scrollbar/js/perfect-scrollbar.jquery.js"></script>
  <script src="views/lib/moment/moment.js"></script>
  <script src="views/lib/jquery-ui/jquery-ui.js"></script>
  <script src="views/lib/jquery-switchbutton/jquery.switchButton.js"></script>
  <script src="views/lib/peity/jquery.peity.js"></script>

  <script src="views/js/bracket.js"></script>